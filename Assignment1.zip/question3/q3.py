import json
from flask import Flask, render_template, request, jsonify   

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("InputOutput.html")    
    

@app.route("/submitJSON", methods=["POST"])
def processJSON(): 
    jsonStr = request.get_json()
    jsonObj = json.loads(jsonStr) 
    
    response = ""
    x=jsonObj['x']
    y=jsonObj['y']
    z=jsonObj['z']
    
    f1=float(x)
    f2=float(y)
    f3=float(z)
    sum=f1+f2+f3
    result1=(f1*f2)/f3
  
    response+="sum of a,b,c is <b> " + str(sum)+ " </b><br>"
    response+="(a*b)/c is <b>" +str(result1) +"</b><br>"
    	    
    return response
    
    
if __name__ == "__main__":
    app.run(debug=True)
    
    
