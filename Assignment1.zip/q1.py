print('''"To be, or not to be: that is the question:
whether 'this nobler in the mind to suffer
the slings and arrows of outrageoud fortune,
Or to take the arms against a sea of troubles,
And by opposing end them.To die; to sleep.."
-Hamlet,Act III, Scene I''')

