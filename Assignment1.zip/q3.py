a=int(input(print("input a")))
b=int(input(print("input b")))
c=int(input(print("input c")))
sum=a+b+c
print("sum of a,b,c is" + sum)
print((a*b)/c)

