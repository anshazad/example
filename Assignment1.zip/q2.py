firstname=input("enter you first name")
lastname=input("enter your last name")
print("welcome" +firstname lastname + "to the IC100 course")

